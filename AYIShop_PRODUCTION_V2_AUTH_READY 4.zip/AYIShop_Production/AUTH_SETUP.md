# AYIShop Auth + Protected Routes

## Environment
Copy `.env.example` to `.env.local` and set:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SERVICE_ROLE_KEY` only when server-side admin operations require it

Never expose `SUPABASE_SERVICE_ROLE_KEY` to browser code.

## Protected routes
`proxy.ts` refreshes Supabase Auth sessions and requires a signed-in user for:
- `/account`
- `/checkout`
- `/admin`

Admin/manager authorization is additionally enforced by the database RLS policies and the admin UI checks the user's `profiles.role`.

## Auth flow
- Email/password signup and login use Supabase Auth.
- User profiles are created automatically by the `on_auth_user_created` trigger.
- Sessions use secure SSR cookies through `@supabase/ssr`.
- Customer order queries are restricted by RLS to the signed-in user's own orders.

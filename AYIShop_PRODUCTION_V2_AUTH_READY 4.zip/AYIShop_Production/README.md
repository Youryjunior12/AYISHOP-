# AYIShop Production V2

Vèsyon sa a elaji starter production AYIShop la avèk storefront, panier, checkout, kont kliyan, commandes, admin products/stock, admin orders, ak MonCash server-side.

## Stack
- Next.js
- Supabase Auth + PostgreSQL + RLS
- MonCash API (server-side)
- Vercel pou hosting

## Kòman pou lanse lokalman
1. `cp .env.example .env.local`
2. Ranpli Supabase + MonCash variables yo.
3. `npm install`
4. `npm run dev`

## Production
1. Kreye yon Supabase project.
2. Kouri `supabase/schema.sql` nan SQL Editor.
3. Kreye premye kont admin nan Supabase Auth, epi chanje `profiles.role` pou `admin`.
4. Mete pwodwi yo nan Admin.
5. Pouse code la sou GitHub.
6. Import repository a nan Vercel.
7. Mete tout Environment Variables yo nan Vercel.
8. Ajoute domain lan nan Vercel epi mete DNS yo kote domain lan achte.
9. Pou MonCash, kòmanse ak sandbox; apre tès yo, itilize credentials production yo epi mete `MONCASH_ENV=live` ak URL production yo.

## Sa ki toujou bezwen pou yon launch biznis reyèl
- aktive/verifye MonCash merchant production
- entegrasyon NatCash/card selon provider yo
- pri livrezon selon zòn/commune
- upload image storage pou pwodwi
- notifications SMS/WhatsApp/email
- policies: Terms, Privacy, Returns
- rate limiting, bot protection, audit logs, monitoring
- tès end-to-end peman/stock/double-click/idempotency

**Pa mete okenn service-role key, MonCash secret oswa modpas nan GitHub.**

import {NextResponse} from "next/server";
import {supabaseAdmin} from "@/lib/supabase-admin";
async function token(){
 const base=process.env.MONCASH_API_BASE!; const id=process.env.MONCASH_CLIENT_ID!; const secret=process.env.MONCASH_CLIENT_SECRET!;
 const auth=Buffer.from(`${id}:${secret}`).toString("base64");
 const r=await fetch(`${base}/oauth/token`,{method:"POST",headers:{Authorization:`Basic ${auth}`,Accept:"application/json","Content-Type":"application/x-www-form-urlencoded"},body:"scope=read,write&grant_type=client_credentials",cache:"no-store"});
 if(!r.ok)throw new Error("MonCash OAuth failed"); return (await r.json()).access_token;
}
export async function POST(req:Request){try{const {orderId,amount}=await req.json();if(!orderId||!amount)return NextResponse.json({error:"orderId and amount required"},{status:400});
 const access=await token();const r=await fetch(`${process.env.MONCASH_API_BASE}/v1/CreatePayment`,{method:"POST",headers:{Authorization:`Bearer ${access}`,Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify({amount,orderId}),cache:"no-store"});const data=await r.json();if(!r.ok)return NextResponse.json({error:data},{status:r.status});
 const t=data?.payment_token?.token;const redirect=t?`${process.env.MONCASH_GATEWAY_BASE}/Payment/Redirect?token=${encodeURIComponent(t)}`:null;
 return NextResponse.json({ok:true,redirect,data});}catch(e:any){return NextResponse.json({error:e.message},{status:500})}}

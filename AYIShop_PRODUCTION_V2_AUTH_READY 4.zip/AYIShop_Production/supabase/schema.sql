-- AYIShop production schema
create extension if not exists pgcrypto;

create type public.user_role as enum ('customer','admin','manager','courier');
create type public.order_status as enum ('pending','confirmed','processing','shipped','out_for_delivery','delivered','cancelled');
create type public.payment_status as enum ('pending','paid','failed','refunded');
create type public.payment_method as enum ('moncash','natcash','card','cod');

create table public.profiles(
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 phone text,
 role public.user_role not null default 'customer',
 created_at timestamptz not null default now()
);

create table public.categories(
 id uuid primary key default gen_random_uuid(),
 name text not null unique,
 slug text not null unique,
 created_at timestamptz not null default now()
);

create table public.products(
 id uuid primary key default gen_random_uuid(),
 category_id uuid references public.categories(id) on delete set null,
 name text not null,
 slug text not null unique,
 description text,
 price_htg numeric(12,2) not null check(price_htg>=0),
 compare_at_htg numeric(12,2),
 stock integer not null default 0 check(stock>=0),
 image_url text,
 active boolean not null default true,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.addresses(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 full_name text not null, phone text not null, department text not null, city text not null,
 address_line text not null, landmark text, created_at timestamptz not null default now()
);

create table public.orders(
 id uuid primary key default gen_random_uuid(),
 order_number bigint generated always as identity unique,
 user_id uuid not null references public.profiles(id) on delete restrict,
 status public.order_status not null default 'pending',
 payment_method public.payment_method not null,
 payment_status public.payment_status not null default 'pending',
 subtotal numeric(12,2) not null check(subtotal>=0),
 delivery_fee numeric(12,2) not null default 0,
 total numeric(12,2) not null check(total>=0),
 address_snapshot jsonb not null,
 payment_reference text,
 transaction_id text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table public.order_items(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null references public.orders(id) on delete cascade,
 product_id uuid not null references public.products(id) on delete restrict,
 product_name text not null,
 unit_price numeric(12,2) not null,
 quantity integer not null check(quantity>0)
);

create table public.shipments(
 id uuid primary key default gen_random_uuid(),
 order_id uuid not null unique references public.orders(id) on delete cascade,
 courier_id uuid references public.profiles(id) on delete set null,
 tracking_code text unique,
 department text not null,
 city text not null,
 status text not null default 'pending',
 notes text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

-- Create profile automatically after signup.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$ begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')); return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Secure tables.
alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.shipments enable row level security;

create policy "public read active products" on public.products for select using(active=true);
create policy "public read categories" on public.categories for select using(true);
create policy "users read own profile" on public.profiles for select to authenticated using(id=auth.uid());
create policy "users update own profile" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "users manage own addresses" on public.addresses for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "users read own orders" on public.orders for select to authenticated using(user_id=auth.uid());
create policy "users read own order items" on public.order_items for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));
create policy "users read own shipments" on public.shipments for select to authenticated using(exists(select 1 from public.orders o where o.id=order_id and o.user_id=auth.uid()));

-- Admin helper.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role in ('admin','manager')); $$;

create policy "admins manage profiles" on public.profiles for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage products" on public.products for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage categories" on public.categories for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage orders" on public.orders for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage order items" on public.order_items for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "admins manage shipments" on public.shipments for all to authenticated using(public.is_admin()) with check(public.is_admin());

-- IMPORTANT: order creation must happen server-side and verify prices/stock.
create or replace function public.create_order(p_user_id uuid,p_items jsonb,p_address jsonb,p_payment_method public.payment_method)
returns public.orders language plpgsql security definer set search_path=public
as $$
declare new_order public.orders; item jsonb; p public.products; subtotal numeric:=0; qty int;
begin
 if p_user_id <> auth.uid() then raise exception 'Unauthorized'; end if;
 if jsonb_array_length(p_items)=0 then raise exception 'Empty cart'; end if;
 for item in select * from jsonb_array_elements(p_items) loop
   select * into p from public.products where id=(item->>'product_id')::uuid and active=true for update;
   if not found then raise exception 'Product unavailable'; end if;
   qty=(item->>'quantity')::int;
   if qty<=0 or p.stock<qty then raise exception 'Insufficient stock'; end if;
   subtotal:=subtotal+(p.price_htg*qty);
 end loop;
 insert into public.orders(user_id,payment_method,subtotal,total,address_snapshot)
 values(p_user_id,p_payment_method,subtotal,subtotal,p_address) returning * into new_order;
 for item in select * from jsonb_array_elements(p_items) loop
   select * into p from public.products where id=(item->>'product_id')::uuid;
   qty=(item->>'quantity')::int;
   insert into public.order_items(order_id,product_id,product_name,unit_price,quantity) values(new_order.id,p.id,p.name,p.price_htg,qty);
   update public.products set stock=stock-qty,updated_at=now() where id=p.id;
 end loop;
 return new_order;
end; $$;

-- Restrict order creation to authenticated users; the function verifies auth.uid() internally.
revoke all on function public.create_order(uuid,jsonb,jsonb,public.payment_method) from public;
grant execute on function public.create_order(uuid,jsonb,jsonb,public.payment_method) to authenticated;

-- Helpful indexes for protected customer/admin queries and RLS joins.
create index if not exists orders_user_id_created_at_idx on public.orders(user_id, created_at desc);
create index if not exists order_items_order_id_idx on public.order_items(order_id);
create index if not exists addresses_user_id_idx on public.addresses(user_id);
create index if not exists shipments_order_id_idx on public.shipments(order_id);
create index if not exists products_active_created_at_idx on public.products(active, created_at desc);
